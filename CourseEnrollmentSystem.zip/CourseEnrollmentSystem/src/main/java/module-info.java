module ces.courseenrollmentsystem {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.base;
    requires java.sql;

    opens ces.courseenrollmentsystem to javafx.fxml;
    exports ces.courseenrollmentsystem;
}
