package ces.courseenrollmentsystem;

import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class RegisterController implements Initializable {

    @FXML
    private TextField firstNameField;

    @FXML 
    private TextField lastNameField;

    @FXML 
    private TextField usernameField;

    @FXML 
    private TextField emailField;

    @FXML 
    private TextField phoneField;

    @FXML 
    private ComboBox<String> roleComboBox;

    @FXML 
    private PasswordField passwordField;

    @FXML 
    private PasswordField confirmPasswordField;

    @FXML
    private Label statusLabel;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        roleComboBox.getItems().addAll("Student");
    }

    @FXML
    public void handleRegister() {
        String firstName = firstNameField.getText().trim();
        String lastName = lastNameField.getText().trim();
        String username = usernameField.getText().trim();
        String email = emailField.getText().trim();
        String phone = phoneField.getText().trim();
        String role = roleComboBox.getValue();
        String password = passwordField.getText();
        String confirmPassword = confirmPasswordField.getText();

    
        if (firstName.isEmpty() || lastName.isEmpty() || username.isEmpty() ||
            email.isEmpty() || role == null || password.isEmpty() || confirmPassword.isEmpty()) {
            statusLabel.setText("Please fill all required fields!");
            return;
        }

        if (!password.equals(confirmPassword)) {
            statusLabel.setText("Passwords do not match!");
            return;
        }

        if (password.length() < 6) {
            statusLabel.setText("Password must be at least 6 characters!");
            return;
        }

        try (Connection conn = DBConnection.connect()) {
     
            String checkSql = "SELECT username FROM register_master WHERE username = ?";
            PreparedStatement checkStmt = conn.prepareStatement(checkSql);
            checkStmt.setString(1, username);
            var rs = checkStmt.executeQuery();
            
            if (rs.next()) {
                statusLabel.setText("Username already exists!");
                return;
            }

            String sql = "INSERT INTO register_master (first_name, last_name, username, email, phone, role, password) VALUES (?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, firstName);
            stmt.setString(2, lastName);
            stmt.setString(3, username);
            stmt.setString(4, email);
            stmt.setString(5, phone);
            stmt.setString(6, role);
            stmt.setString(7, password);

            int rows = stmt.executeUpdate();

            if (rows > 0) { 
                statusLabel.setText("Registration Successful!");
                clearFields();
            } else {
                statusLabel.setText("Registration Failed!");
            }

        } catch (Exception e) {
            e.printStackTrace();
            statusLabel.setText("Database Error: " + e.getMessage());
        }
    }

    @FXML
    public void handleBackToLogin() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("Login.fxml"));
            Scene scene = new Scene(loader.load());
            Stage stage = (Stage) firstNameField.getScene().getWindow(); 
            stage.setScene(scene);
            stage.setTitle("Login - Course Enrollment System");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void clearFields() {
        firstNameField.clear();
        lastNameField.clear();
        usernameField.clear();
        emailField.clear();
        phoneField.clear();
        passwordField.clear();
        confirmPasswordField.clear();
        roleComboBox.getSelectionModel().clearSelection();
    }
}