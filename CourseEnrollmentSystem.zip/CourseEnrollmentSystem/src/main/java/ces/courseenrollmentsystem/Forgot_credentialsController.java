package ces.courseenrollmentsystem;

import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class Forgot_credentialsController implements Initializable { // Fixed class name

    @FXML
    private TextField firstNameField;
    
        @FXML
    private TextField lastNameField;

    @FXML
    private TextField emailField;

    @FXML
    private TextField phoneField;

    @FXML
    private ComboBox<String> roleComboBox;

    @FXML
    private Label statusLabel;

    private String verifiedEmail; // Store verified email for password reset

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        roleComboBox.getItems().addAll("Student", "Faculty", "Admin");
    }

    @FXML
    private void handleRecovery() {
        String firstName = firstNameField.getText().trim();
        String lastName = lastNameField.getText().trim();
        String email = emailField.getText().trim();
        String phone = phoneField.getText().trim();
        String role = (roleComboBox.getValue() != null) ? roleComboBox.getValue().trim() : "";

        if (firstName.isEmpty() || lastName.isEmpty() ||email.isEmpty() || phone.isEmpty() || role.isEmpty()) {
            statusLabel.setText("Please fill all required fields.");
            return;
        }

        // Database verification
        try (Connection conn = DBConnection.connect()) {
            String sql = "SELECT email FROM register_master WHERE first_name || ' ' || last_name = ? AND email = ? AND phone = ? AND role = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, firstName);
            stmt.setString(2, lastName);
            stmt.setString(3, email);
            stmt.setString(4, phone);
            stmt.setString(5, role);

            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                verifiedEmail = rs.getString("email");
                statusLabel.setText("Identity verified! Redirecting...");
                goToPasswordReset();
            } else {
                statusLabel.setText("Details did not match our records.");
            }

        } catch (Exception e) {
            e.printStackTrace();
            statusLabel.setText("Database error: " + e.getMessage());
        }
    }

    private void goToPasswordReset() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("password_reset.fxml")); // Fixed file name
            Parent root = loader.load();
            
            // Pass the verified email to the password reset controller
            Password_resetController controller = loader.getController();
            controller.setUserEmail(verifiedEmail);
            
            Stage stage = (Stage) statusLabel.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("Reset Password - Course Enrollment System");
        } catch (Exception e) {
            e.printStackTrace();
            statusLabel.setText("Error loading password reset page!");
        }
    }

    @FXML
    private void handleBackToLogin() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("Login.fxml"));
            Parent root = loader.load();
            Stage stage = (Stage) statusLabel.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("Login - Course Enrollment System");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}