/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ces.courseenrollmentsystem;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


/**
 *
 * @author Ashish Bharadwaj
 */
public class DBConnection {
    
    private static final String URL="jdbc:mysql://127.0.0.1:3306/course_enrollment";
    private static final String USER="root";
    private static final String PASSWORD="root";
    
public static Connection connect() {
    try {
        Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
        System.out.println("Database Connected Successfully!");
        return conn;
    } catch (SQLException e) {
        System.out.println("Database Connection Failed: " + e.getMessage());
        return null;
    }
}

    
}
