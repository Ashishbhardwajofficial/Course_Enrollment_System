package ces.courseenrollmentsystem;

import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.stage.Stage;

public class Password_resetController implements Initializable { 

    @FXML
    private PasswordField newPasswordField;

    @FXML
    private PasswordField confirmPasswordField;

    @FXML
    private Label statusLabel;

    @FXML
    private Label userInfoLabel;

    private String userEmail;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        statusLabel.setText("");
    }

    public void setUserEmail(String email) {
        this.userEmail = email;
        userInfoLabel.setText("Resetting password for: " + email);
    }

    @FXML
    private void handlePasswordReset() {
        String newPassword = newPasswordField.getText().trim();
        String confirmPassword = confirmPasswordField.getText().trim();

        if (newPassword.isEmpty() || confirmPassword.isEmpty()) {
            statusLabel.setText("Please fill all fields.");
            return;
        }

        if (!newPassword.equals(confirmPassword)) {
            statusLabel.setText("Passwords do not match!");
            return;
        }

        if (newPassword.length() < 6) {
            statusLabel.setText("Password must be at least 6 characters long.");
            return;
        }

        if (userEmail == null || userEmail.isEmpty()) {
            statusLabel.setText("User email not found. Please start over.");
            return;
        }

        try (Connection conn = DBConnection.connect()) {
            String sql = "UPDATE register_master SET password = ? WHERE email = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, newPassword);
            stmt.setString(2, userEmail);

            int rows = stmt.executeUpdate();

            if (rows > 0) {
                statusLabel.setText("Password reset successful! Redirecting to login...");
              
                new java.util.Timer().schedule(
                    new java.util.TimerTask() {
                        @Override
                        public void run() {
                            javafx.application.Platform.runLater(() -> {
                                try {
                                    goToLogin();
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                            });
                        }
                    },
                    2000
                );
            } else {
                statusLabel.setText("No user found with this email.");
            }

        } catch (Exception e) {
            e.printStackTrace();
            statusLabel.setText("Error updating password: " + e.getMessage());
        }
    }

    @FXML
    private void handleBack() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("forgot_credentials.fxml"));
            Parent root = loader.load();
            Stage stage = (Stage) statusLabel.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("Forgot Credentials - Course Enrollment System");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void goToLogin() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("Login.fxml"));
            Parent root = loader.load();
            Stage stage = (Stage) statusLabel.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("Login - Course Enrollment System");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}