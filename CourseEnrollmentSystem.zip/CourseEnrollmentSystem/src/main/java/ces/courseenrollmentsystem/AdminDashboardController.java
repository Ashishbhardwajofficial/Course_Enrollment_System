package ces.courseenrollmentsystem;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.event.ActionEvent;
import javafx.scene.layout.AnchorPane;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.Node;
import javafx.event.ActionEvent;
import java.io.IOException;


import java.net.URL;
import java.util.ResourceBundle;

public class AdminDashboardController implements Initializable {

 
    @FXML private Label welcomeadmin;
    @FXML private Button logoutButtonAdm;
    @FXML private TextField nemailgenarator;
    @FXML private ComboBox<String> rolefroemail;
    @FXML private Button rmillsumbit;
    @FXML private TextField courseecodee;
    @FXML private TextField coursenamee;
    @FXML private TextField semesee;
    @FXML private ComboBox<String> departmentname;
    @FXML private Button submitee;
    @FXML private Button cancelttt;
    @FXML private ComboBox<String> fmdepartment;
    @FXML private TextField fmdesignation;
    @FXML private TextField fmqualification;
    @FXML private TextField fmexperiebnces;
    @FXML private TextField fmemailid;
    @FXML private ComboBox<String> fmgender;
    @FXML private TextField fmspecilaization;
    @FXML private Button fmSubmiteey;
    @FXML private TextField coursecody;
    @FXML private TextField coursynamy;
    @FXML private Button deparmentsubmital;

    @FXML private Label Userid;
    @FXML private Label eamilid;
    @FXML private Button editprofieey;


    @FXML private AnchorPane ContentArea;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        ObservableList<String> roles = FXCollections.observableArrayList("Admin", "Faculty");
        rolefroemail.setItems(roles);

        ObservableList<String> departments = FXCollections.observableArrayList(
                "Department Of Computer Science", "Department Of Information Technology", "Department Of Mechanical", "Department Of Electrical", "Department Of Civil","Department Of Computer Application","Department Of Management"
        );
        departmentname.setItems(departments);
        fmdepartment.setItems(departments);


        ObservableList<String> genders = FXCollections.observableArrayList("Male", "Female", "Other");
        fmgender.setItems(genders);
    }

    @FXML
    private void handlinsubmit(ActionEvent event) {
        String role = rolefroemail.getValue();
        String email = nemailgenarator.getText();

        if (role == null || email.isEmpty()) {
            showAlert("Incomplete Data", "Please select role and enter email.");
            return;
        }

        String generatedEmail = role.toLowerCase() + "_" + System.currentTimeMillis() + "@ces.in";
        System.out.println("Generated Email: " + generatedEmail);

        showAlert("User Created", "Role: " + role + "\nEmail: " + generatedEmail);
    }

    @FXML
    private void handlesubmitee(ActionEvent event) {
        String courseName = coursenamee.getText();
        String courseCode = courseecodee.getText();
        String semester = semesee.getText();
        String department = departmentname.getValue();

        if (courseName.isEmpty() || courseCode.isEmpty() || semester.isEmpty() || department == null) {
            showAlert("Incomplete Data", "Please fill all course details.");
            return;
        }

        System.out.println("Course Added → " + courseName + " (" + courseCode + ") | " + department + " | Sem " + semester);
        showAlert("Success", "Course added successfully.");
    }

    @FXML
    private void canciii(ActionEvent event) {
        coursenamee.clear();
        courseecodee.clear();
        semesee.clear();
        departmentname.getSelectionModel().clearSelection();
        System.out.println("Course form cleared.");
    }

    @FXML
    private void handledeptid(ActionEvent event) {
        String dept = departmentname.getValue();
        if (dept != null) {
            System.out.println("Department selected: " + dept);
        }
    }
    
    @FXML
    private void handlefmsumitee(ActionEvent event) {
        String dept = fmdepartment.getValue();
        String designation = fmdesignation.getText();
        String qualification = fmqualification.getText();
        String experience = fmexperiebnces.getText();
        String email = fmemailid.getText();
        String gender = fmgender.getValue();
        String specialization = fmspecilaization.getText();

        if (dept == null || designation.isEmpty() || qualification.isEmpty() || experience.isEmpty() || email.isEmpty() || gender == null || specialization.isEmpty()) {
            showAlert("Incomplete Data", "Please fill all faculty details.");
            return;
        }

        System.out.println("Faculty Added → " + email + " | " + dept + " | " + designation);
        showAlert("Success", "Faculty added successfully.");
    }


    @FXML
    private void handleDepartmentSubmit(ActionEvent event) {
        String code = coursecody.getText();
        String name = coursynamy.getText();

        if (code.isEmpty() || name.isEmpty()) {
            showAlert("Incomplete Data", "Please fill department code and name.");
            return;
        }

        System.out.println("Department Added → " + code + " - " + name);
        showAlert("Success", "Department added successfully.");
    }

@FXML
private void handleLogoutAdm(ActionEvent event) {
    try {
       
        FXMLLoader loader = new FXMLLoader(getClass().getResource("Login.fxml"));
        Parent root = loader.load();

     
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();

        System.out.println("Admin logged out and redirected to login page.");

    } catch (IOException e) {
        e.printStackTrace();
        showAlert("Error", "Failed to load login page.");
    }
}


    @FXML
    private void handleEditProfile(ActionEvent event) {
        System.out.println("Edit profile clicked.");
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
