package ces.courseenrollmentsystem;

import java.net.URL;
import java.sql.*;
import java.time.LocalTime;
import java.util.ResourceBundle;
import javafx.stage.Stage;
import javafx.animation.FadeTransition;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.util.Duration;
import javafx.scene.Node;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;

public class StudentDashboardController implements Initializable {

    @FXML private Label welcomestudent;
    @FXML private Button logoutButtonStd;
    @FXML private Label gradesachive;
    @FXML private ProgressIndicator studtotalAttendanceper;
    @FXML private VBox studavilablecours;

    @FXML private TextField fullnamee, fathername, mothername, Addresss;
    @FXML private TextField rollno, Phonenoo, semester;
    @FXML private DatePicker dateofbirthh;
    @FXML private ComboBox<String> courses;
    @FXML private ComboBox<String> hscstreamm;
    @FXML private TextField Hscclass, Hscboarname, Hscpercentage;
    @FXML private TextField ssclass, sscboardname, sscpercent;
    @FXML private TextField graduatiouniversiy, gradutaiondegreen, graduationpercentage;
    @FXML private Button submitenroll, cancleenrollment;

    @FXML private Label enrolledcoursbystud;
    @FXML private Label fetchfirstname, fetchlastname, fetchemail;
    @FXML private Button Editprofle;
    @FXML private TabPane studtabpane;

    private String loggedInName = "";
    private String loggedInEmail = "";
    private int loggedInUserId = 1;

    public void setStudentName(String name) {
        this.loggedInName = name;
        updateGreeting();
        fetchfirstname.setText(name);
    }

    public void setStudentEmail(String email) {
        this.loggedInEmail = email;
        fetchemail.setText(email);
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        courses.getItems().addAll("BCA", "MCA", "BSc Computer Science", "MBA");
        hscstreamm.getItems().addAll("Science", "Commerce", "Arts");

        studtotalAttendanceper.setProgress(0.76);
        gradesachive.setText("Grade: A+");

        applyAnimations();
        updateGreeting();

        if (!loggedInEmail.isEmpty()) loadStudentProfile();

        loadEnrollmentDetailsFromDB();
    }

    private void updateGreeting() {
        LocalTime now = LocalTime.now();

        String greeting =
                (now.isBefore(LocalTime.NOON)) ? "🌞 Good Morning, " :
                        (now.isBefore(LocalTime.of(17, 0))) ? "🌤️ Good Afternoon, "
                                : "🌙 Good Evening, ";

        if (loggedInName != null && !loggedInName.isEmpty()) {
            welcomestudent.setText(greeting + loggedInName);
        } else {
            welcomestudent.setText(greeting + "Student");
        }
    }

    private void applyAnimations() {
        FadeTransition fadeIn = new FadeTransition(Duration.seconds(1.5), studtabpane);
        fadeIn.setFromValue(0);
        fadeIn.setToValue(1);
        fadeIn.play();
    }

    private void loadStudentProfile() {
        String query = "SELECT firstname, lastname, email FROM students WHERE email = ?";

        try (Connection con = DBConnection.connect();
             PreparedStatement ps = con.prepareStatement(query)) {

            ps.setString(1, loggedInEmail);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                String fname = rs.getString("firstname");
                String lname = rs.getString("lastname");

                fetchfirstname.setText(fname);
                fetchlastname.setText(lname);
                fetchemail.setText(rs.getString("email"));

                this.loggedInName = fname;
                updateGreeting();

            } else {
                fetchemail.setText(loggedInEmail);
            }

        } catch (SQLException e) {
            showAlert(Alert.AlertType.ERROR, "Database Error", e.getMessage());
        }
    }

    @FXML
    private void loadEnrollmentDetails(ActionEvent event) {
        loadEnrollmentDetailsFromDB();
    }

    private void loadEnrollmentDetailsFromDB() {

        String query = "SELECT full_name, fathers_name, mothers_name, roll_no, phone_no, semester, "
                + "address, graduation_percentage, hsc_stream, Date_of_birth "
                + "FROM student_master WHERE user_id = ?";

        try (Connection con = DBConnection.connect();
             PreparedStatement ps = con.prepareStatement(query)) {

            ps.setInt(1, loggedInUserId);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                String details =
                        "📘 Student Enrollment Details\n\n" +
                                "Name: " + rs.getString("full_name") + "\n" +
                                "Father's Name: " + rs.getString("fathers_name") + "\n" +
                                "Mother's Name: " + rs.getString("mothers_name") + "\n" +
                                "Roll No: " + rs.getString("roll_no") + "\n" +
                                "Phone No: " + rs.getString("phone_no") + "\n" +
                                "Semester: " + rs.getString("semester") + "\n" +
                                "Stream: " + rs.getString("hsc_stream") + "\n" +
                                "Address: " + rs.getString("address") + "\n" +
                                "Graduation %: " + rs.getString("graduation_percentage") + "\n" +
                                "Date of Birth: " + rs.getString("Date_of_birth");

                enrolledcoursbystud.setText(details);
            } else {
                enrolledcoursbystud.setText("No enrollment data found.");
            }

        } catch (SQLException e) {
            enrolledcoursbystud.setText("Error loading: " + e.getMessage());
        }
    }

    @FXML
    private void handlesubmitenroll(ActionEvent event) {

        if (fullnamee.getText().isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "Error", "Enter Full Name!");
            return;
        }

        String query =
                "INSERT INTO student_master (user_id, full_name, fathers_name, mothers_name, roll_no, "
                        + "semester, Date_of_birth, address, phone_no, hsc_boardname, hsc_class, "
                        + "hsc_percentage, hsc_stream, graduationdegree_or_diploma, "
                        + "graduation_university, graduation_percentage, gender) "
                        + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection con = DBConnection.connect();
             PreparedStatement ps = con.prepareStatement(query)) {

            ps.setInt(1, loggedInUserId);
            ps.setString(2, fullnamee.getText());
            ps.setString(3, fathername.getText());
            ps.setString(4, mothername.getText());
            ps.setString(5, rollno.getText());
            ps.setInt(6, Integer.parseInt(semester.getText()));
            ps.setString(7, dateofbirthh.getValue().toString());
            ps.setString(8, Addresss.getText());
            ps.setString(9, Phonenoo.getText());
            ps.setString(10, Hscboarname.getText());
            ps.setInt(11, Integer.parseInt(Hscclass.getText()));
            ps.setBigDecimal(12, new java.math.BigDecimal(Hscpercentage.getText()));
            ps.setString(13, hscstreamm.getValue());
            ps.setString(14, gradutaiondegreen.getText());
            ps.setString(15, graduatiouniversiy.getText());
            ps.setBigDecimal(16, new java.math.BigDecimal(graduationpercentage.getText()));
            ps.setString(17, "male");

            int rows = ps.executeUpdate();

            if (rows > 0) {
                showAlert(Alert.AlertType.INFORMATION, "Success", "Enrollment Saved!");
                clearEnrollmentForm();
                loadEnrollmentDetailsFromDB();
            }

        } catch (SQLException e) {
            showAlert(Alert.AlertType.ERROR, "DB Error", e.getMessage());
        }
    }

  
    @FXML
    private void Cancleenrollment(ActionEvent event) {
        clearEnrollmentForm();
        showAlert(Alert.AlertType.INFORMATION, "Cancelled", "Form Cleared.");
    }

    private void clearEnrollmentForm() {
        fullnamee.clear();
        fathername.clear();
        mothername.clear();
        Addresss.clear();
        rollno.clear();
        Phonenoo.clear();
        semester.clear();
        dateofbirthh.setValue(null);
        Hscclass.clear();
        Hscboarname.clear();
        Hscpercentage.clear();
        ssclass.clear();
        sscboardname.clear();
        sscpercent.clear();
        graduatiouniversiy.clear();
        gradutaiondegreen.clear();
        graduationpercentage.clear();
        courses.setValue(null);
        hscstreamm.setValue(null);
    }

    @FXML
    private void handleprfileedit(ActionEvent event) {
        showAlert(Alert.AlertType.INFORMATION, "Info", "Profile editing coming soon!");
    }

    @FXML
    private void handleLogoutStd(ActionEvent event) {
    Alert alert = new Alert(Alert.AlertType.CONFIRMATION, 
            "Are you sure to logout?", ButtonType.YES, ButtonType.NO);

    if (alert.showAndWait().get() == ButtonType.YES) {

        try {
            
            FXMLLoader loader = new FXMLLoader(getClass().getResource("Login.fxml"));
            Parent root = loader.load();

            
            Stage currentStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            currentStage.close();

           
            Stage stage = new Stage();
            stage.setScene(new Scene(root));
            stage.setTitle("Login");
            stage.show();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}


    private void showAlert(Alert.AlertType type, String title, String msg) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(msg);
        alert.showAndWait();
    }
}
