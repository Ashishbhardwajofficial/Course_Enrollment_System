package ces.courseenrollmentsystem;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class LoginController {

    @FXML private TextField usernameField;
    @FXML private PasswordField passwordField;
    @FXML private Label statusLabel;

    @FXML
    public void initialize() {
        statusLabel.setText("Welcome! Please log in.");
    }

    @FXML
    private void handleLogin() {
        String username = usernameField.getText();
        String password = passwordField.getText();

        if (username.isEmpty() || password.isEmpty()) {
            showMessage("Please enter username and password!");
            return;
        }

        String sql = "SELECT * FROM register_master WHERE username=? AND password=?";

        try (Connection con = DBConnection.connect();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, username);
            ps.setString(2, password);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                openPage("/ces/courseenrollmentsystem/StudentDashboard.fxml", "Student Dashboard");
            } else {
                showMessage("Invalid username or password!");
            }

        } catch (Exception e) {
            showMessage("Database Error: " + e.getMessage());
        }
    }

    private void openPage(String fxml, String title) {
        try {
            Parent root = FXMLLoader.load(getClass().getResource(fxml));
            Stage stage = (Stage) usernameField.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle(title);
            stage.show();
        } catch (Exception e) {
            showMessage("Unable to load page: " + title + "\nError: " + e.getMessage());
        }
    }

    @FXML
    private void handleCancel() {
        usernameField.clear();
        passwordField.clear();
        statusLabel.setText("Login cancelled.");
    }


    @FXML
    private void handleForgotPassword() {
        openPage("/ces/courseenrollmentsystem/forgot_credentials.fxml", "Forgot Password");
    }


    @FXML
    private void handleSignup() {
        openPage("/ces/courseenrollmentsystem/Register.fxml", "Signup");
    }

    private void showMessage(String msg) {
        Alert a = new Alert(Alert.AlertType.INFORMATION);
        a.setHeaderText(null);
        a.setContentText(msg);
        a.show();
    }
}
