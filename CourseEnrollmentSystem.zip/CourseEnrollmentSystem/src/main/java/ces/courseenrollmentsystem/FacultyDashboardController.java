package ces.courseenrollmentsystem;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;

import java.net.URL;
import java.util.ResourceBundle;

public class FacultyDashboardController implements Initializable {

    @FXML private Label welcomefaculty;
    @FXML private AnchorPane ContentArea;

    private String loggedFacultyName = "Faculty";

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        welcomefaculty.setText("Welcome, " + loggedFacultyName);
        loadUI("faculty_home");
    }

    private void loadUI(String fxmlName) {
        try {
            Parent root = FXMLLoader.load(getClass().getResource(fxmlName + ".fxml"));
            ContentArea.getChildren().clear();
            ContentArea.getChildren().add(root);

            AnchorPane.setTopAnchor(root, 0.0);
            AnchorPane.setBottomAnchor(root, 0.0);
            AnchorPane.setLeftAnchor(root, 0.0);
            AnchorPane.setRightAnchor(root, 0.0);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void setFacultyName(String name) {
        this.loggedFacultyName = name;
        welcomefaculty.setText("Welcome, " + name);
    }


    @FXML
    private void handleDashboardFaculty() {
        loadUI("faculty_home");
    }

    @FXML
    private void HandleGsFaculty() {
        loadUI("faculty_grade_submission");
    }

    @FXML
    private void handleCoursFaculty() {
        loadUI("faculty_courses");
    }

    @FXML
    private void handlestudmanag() {
        loadUI("faculty_student_management");
    }

    @FXML
    private void handleMyProFaculty() {
        loadUI("faculty_profile");
    }


    @FXML
    private void handleLogoutFaculty() {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Logout Confirmation");
        alert.setHeaderText("You're about to logout!");
        alert.setContentText("Do you really want to logout?");

        if (alert.showAndWait().get() == ButtonType.OK) {
            System.out.println("Faculty Logged Out!");
        }
    }
}
